# _packages/guiapp/simple_gui.py
import tkinter as tk
from tkinter import messagebox

def create_simple_gui():
    """
    Creates and runs a simple Tkinter GUI window.
    """
    root = tk.Tk()
    root.title("PyOS Simple GUI")
    root.geometry("400x200")
    root.resizable(False, False) # Prevent resizing

    # Center the window (basic attempt)
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width / 2) - (400 / 2)
    y = (screen_height / 2) - (200 / 2)
    root.geometry(f'+{int(x)}+{int(y)}')

    label = tk.Label(root, text="Hello from PyOS GUI!", font=("Arial", 16))
    label.pack(pady=20)

    def show_info():
        messagebox.showinfo("Info", "This is a basic GUI launched from PyOS!")

    info_button = tk.Button(root, text="Show Info", command=show_info)
    info_button.pack(pady=10)

    # Add a button to close the window
    close_button = tk.Button(root, text="Close GUI", command=root.destroy)
    close_button.pack(pady=5)

    root.mainloop()

if __name__ == "__main__":
    # This block allows simple_gui.py to be run directly for testing,
    # or by subprocess.Popen from PyOS.
    create_simple_gui()

# _packages/guiapp/__init__.py
import subprocess
import sys
from pathlib import Path

# Get the path to the simple_gui.py script within this package
# This is crucial for launching it as a separate process
_gui_script_path = Path(__file__).parent / "simple_gui.py"

def register_shell_commands(register_func):
    """
    Called by PyOS to register commands provided by this package.
    """
    register_func("rungui", handle_rungui_command)
    print("Package 'guiapp' registered 'rungui' command.")

def handle_rungui_command(args):
    """
    Handles the 'rungui' command for PyOS.
    Launches a simple Tkinter GUI in a separate process.
    """
    if args:
        print("Usage: rungui (no arguments expected)")
        return

    print("Launching Simple GUI application...")
    try:
        # Launch the simple_gui.py script using subprocess.Popen
        # This runs it in a new Python interpreter process,
        # so it doesn't block the main PyOS shell.
        # sys.executable ensures we use the same Python interpreter that PyOS is running on.
        process = subprocess.Popen([sys.executable, str(_gui_script_path)])
        # You could store 'process' if you wanted to manage its lifecycle (e.g., kill it)
        # For now, we just launch it.
        print(f"GUI application launched with PID: {process.pid}")
    except FileNotFoundError:
        print(f"Error: GUI script not found at {_gui_script_path}", file=sys.stderr)
    except Exception as e:
        print(f"Error launching GUI application: {e}", file=sys.stderr)

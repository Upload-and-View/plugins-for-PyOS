# _packages/calculator/__init__.py

# This might define the command handler directly
def handle_calc_command(args):
    """
    Handles the 'calc' command.
    Example: calc add 5 3
    """
    if len(args) < 3:
        print("Usage: calc <operation> <num1> <num2>")
        return

    operation = args[0]
    try:
        num1 = float(args[1])
        num2 = float(args[2])
    except ValueError:
        print("Error: Invalid numbers.")
        return

    if operation == "add":
        print(f"Result: {num1 + num2}")
    elif operation == "sub":
        print(f"Result: {num1 - num2}")
    elif operation == "mul":
        print(f"Result: {num1 * num2}")
    elif operation == "div":
        print(f"Result: {num1 / num2}")
    elif operation == "mod":
        print(f"Result: {num1 % num2}")
    elif operation == "pow":
        print(f"Result: {num1 ** num2}")
    else:
        print(f"Error: Unknown operation '{operation}'")

# Optionally, if you had a calculator.py, you could import from it:
# from . import calculator_logic # if calculator_logic was in calculator.py
# If you wanted to expose 'calc' as a top-level command, you'd need a way to register it.
# This brings us back to the 'plugin' concept or a registry.
